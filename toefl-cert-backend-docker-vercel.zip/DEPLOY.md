# Deploy: Vercel (live) + Docker (portable) + GitHub Actions (CI)

Backend ini bisa jalan dengan dua cara dari kode yang sama:

| Cara | Untuk apa | Chromium (PDF) |
|------|-----------|----------------|
| **Vercel** (serverless) | Link live untuk portfolio, gratis, tanpa kartu | `@sparticuz/chromium` |
| **Docker** | Dijalankan lokal / VPS, tampil di repo sebagai bukti skill Docker | Chromium sistem di image |

## 1. Jalankan dengan Docker
```bash
cp .env.example .env     # isi nilainya (PORT di compose sudah 5000)
docker compose up --build
curl http://localhost:5000/api/health
```
Buat akun admin pertama (sekali saja, butuh MONGODB_URI di .env):
```bash
docker compose run --rm api node scripts/seed.js
```

## 2. CI: build & publish image ke GitHub Container Registry (gratis)
File: `.github/workflows/docker-publish.yml`

- **Pull request ke `main`**: build image + smoke test (app ter-load, puppeteer-core ada, Chromium terpasang).
- **Push ke `main`**: build + smoke test, lalu push ke `ghcr.io/<username>/<repo>` dengan tag `latest` dan `sha-xxxxxxx`.
- Tidak perlu secret tambahan: memakai `GITHUB_TOKEN` bawaan.

Menjalankan image hasil CI di mesin mana pun:
```bash
docker pull ghcr.io/<username>/<repo>:latest
docker run -d -p 5000:5000 --env-file .env ghcr.io/<username>/<repo>:latest
```
> Package ghcr awalnya private. Untuk dilihat publik: GitHub → Packages → pilih package →
> Package settings → Change visibility.

## 3. Deploy ke Vercel (backend sebagai project terpisah dari frontend)
1. Vercel → **Add New → Project** → pilih repo backend ini. Framework Preset: **Other**.
2. Settings → **General → Node.js Version**: pilih **22.x** (minimal 20.11).
3. Settings → **Environment Variables**, isi:
   `MONGODB_URI`, `SEPOLIA_RPC_URL`, `PRIVATE_KEY`, `CONTRACT_ADDRESS`, `JWT_SECRET`,
   `FRONTEND_URL` (domain Vercel frontend), `QR_BASE_URL` (`https://domain-frontend/verify`),
   `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET`,
   `TRUST_PROXY=true`, `NODE_ENV=production`.
4. Deploy. Cek `https://<project>.vercel.app/api/health`.
5. Di frontend, arahkan URL API ke domain backend tadi, lalu redeploy frontend.
6. Buat admin: jalankan **dari laptop** `npm run seed` dengan `.env` yang berisi MONGODB_URI Atlas yang sama
   (di Vercel tidak ada shell).

Setiap `git push` ke `main` otomatis memicu deploy Vercel.

### Checklist keamanan (penting untuk repo publik)
- `PRIVATE_KEY`: pakai wallet **baru khusus Sepolia**, bukan wallet utama.
- Jangan commit `.env`. Kalau pernah ter-commit/ter-share, ganti semua key (RPC, Cloudinary, JWT, Mongo).
- MongoDB Atlas → Network Access: izinkan `0.0.0.0/0` (IP Vercel berubah-ubah), pakai user DB dengan password kuat.

### Batasan serverless yang perlu diketahui
- Request pertama setelah lama sepi lebih lambat (cold start); generate PDF paling berat. Fungsi dibatasi `maxDuration: 60` detik di `vercel.json`.
- Terbitkan batch kecil saat demo; batch besar bisa kena batas waktu/memori Vercel.
- Rate limit tersimpan di memori per instance, jadi bersifat perkiraan di serverless.
- Batas paket gratis Vercel bisa berubah; cek dashboard Vercel kalau muncul error timeout/memori.
